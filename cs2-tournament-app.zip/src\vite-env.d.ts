/// <reference types="vite/client" />

